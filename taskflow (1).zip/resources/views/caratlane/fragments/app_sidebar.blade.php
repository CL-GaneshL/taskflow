
<!-- start: SIDEBAR -->

<nav data-ng-include="'taskflow/fragments/app_sidebar_navbar'"></nav>

<!-- end: SIDEBAR -->
