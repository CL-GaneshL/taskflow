
<!-- start: MAIN CONTENT -->
<div ui-view class="wrap-content container fade-in-up" id="container"></div>
<!-- end: MAIN CONTENT -->