
<!---------------------------------------------------------------->
<!-- footer                                                     -->
<!---------------------------------------------------------------->
<div class="footer-inner col-xs-12">


    <div class="pull-left col-xs-9">
        &copy; <% app.year %> 
        <span class="text-bold text-uppercase"><% app.author %></span>
        . 
        <span>All rights reserved</span> 
    </div>

    <div class="col-xs-1 pull-right padding-right-0">
        <span class="go-top" ng-click="toTheTop()">
            <i class="ti-angle-up"></i>
        </span>
    </div>

</div>

